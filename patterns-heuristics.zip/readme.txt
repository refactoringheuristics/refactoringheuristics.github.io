Neo4J
This neo4j-community-3.1.0.zip file contains data related to the 48 open source projects used in our study. For each project, we collected refactoring operations and code smells for all commits.

Database Credentials
Login: neo4j
Password: boil2.eat

Nodes
The file contains a Neo4j database with 5 types of nodes:

- Project: Nodes like this one contains metadata about the projects considered (name and url, for instance)
- Commit: These notes store data related to commits of each project (date, author, comment, etc.)
- Element: It represents code elements (methods, classes, interfaces, etc.). These nodes store all sort of data related to code elements: fqn, metrics values, file name, location in the code, etc.
- Refactoring: It represents all refactoring operations by type and impact over code smells (if removed or not the smell).
- Smell: All instances of code smells by type and affected code element.

Relationships
The nodes relates to each other according to the following relationships:

(Commit)-[:BELONGS_TO]->(Project) - Links commits to projects

(Element)-[:COMMITTED_IN]->(Commit) - Links code element to specific commits

(Element)-[:AFFECTED_BY]->(Smell) - Links elements to the smells that affect them

(Refactoring)-[:STARTED_AT]->(Commit) - Commit immediately before refactoring

(Refactoring)-[:CHANGED]->(Element) - Code elements affected by the refactoring, but in the previous state, i.e., before the refactoring actually be performed

(Refactoring)-[:PRODUCED]->(Element) - Code elements in the state after refactoring. It may contain new elements not contained in the :CHANGED relationship because refactorings can also create new elements.

(b:Batch)-->(r:Refactoring)-->(c:Commit)-->(p:Project) - All the composites in the project. To specify a category of a composite (element-based, commit-based or range-based composites), you need to set its type (e.g., b.type = 'element-based').

Links
Since this file is a Neo4j database, please refer to these links to interact with the data:

Overview: https://neo4j.com/developer/get-started/
Starting the database and querying data: https://neo4j.com/developer/guide-neo4j-browser/
Cypher Cheat Sheet: https://neo4j.com/docs/cypher-refcard/current/

- The attached file "Composite-SmellPatterns.pdf" contains the patterns for all code smells.
- The attached file "Selected Projects.pdf" contains additional data about the projects we considered in this research.
- The attached file "Scripts.zip" contains our scripts to detect element-based, commit-based and range-based composites